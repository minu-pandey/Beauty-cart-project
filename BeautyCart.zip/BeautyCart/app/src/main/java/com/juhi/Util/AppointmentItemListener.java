package com.juhi.Util;

public interface AppointmentItemListener {
    void onDatasetChanged(int size);
}
