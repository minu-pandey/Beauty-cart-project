package com.juhi.Util;

public interface OnAppointmentItemClickListener {
    void onRepeatOrderPlaced();
    void onOrderCancelled();
}
