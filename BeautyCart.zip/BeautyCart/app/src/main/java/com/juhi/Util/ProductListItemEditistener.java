package com.juhi.Util;

public interface ProductListItemEditistener {
    void onProductSelected(int selected_position);
}
